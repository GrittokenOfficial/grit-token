
# GRIT Token

GRIT Token is a community-driven cryptocurrency built to empower blue-collar workers and self-starters. Fueled by Binance Smart Chain (BSC), GRIT represents strength, transparency, and real-world utility.

## 🔐 Contract

**Address:** `0x5f959c4f736f271d52322a833af57baa3e8d4195`  
**Network:** Binance Smart Chain (BEP-20)

## 💡 Mission

To reward hard work and hustle by building a decentralized token that supports blue-collar communities through utility and financial empowerment.

## 📊 Tokenomics

- **Total Supply:** 1,000,000,000 GRIT
- **Liquidity Locked:** ✅
- **Fair Launch:** ✅
- **No Dev Wallet:** ✅

## 📎 Links

- Website: [https://grittokenofficial.netlify.app](https://grittokenofficial.netlify.app)
- Twitter: [https://twitter.com/Peculier1](https://twitter.com/Peculier1)

## 📄 License

This project is licensed under the MIT License.
